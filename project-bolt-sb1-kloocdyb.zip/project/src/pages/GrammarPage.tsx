import React from 'react';
import { useStore } from '../store/useStore';
import { Book, BookOpen, GraduationCap } from 'lucide-react';

const GrammarPage: React.FC = () => {
  const { language } = useStore();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-4">
        {language === 'mn' ? 'Япон хэлний дүрэм' : '日本語文法'}
      </h1>
      <p className="text-gray-600 mb-8">
        {language === 'mn' 
          ? 'JLPT түвшин бүрийн дүрмийн тайлбар' 
          : 'JLPT各レベルの文法解説'}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="col-span-1 lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Түвшин сонгох' : 'レベルを選択'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {['N1', 'N2', 'N3', 'N4', 'N5'].map((level) => (
                <button
                  key={level}
                  className="flex items-center justify-center space-x-2 bg-gray-50 hover:bg-indigo-50 text-gray-700 hover:text-indigo-600 px-4 py-3 rounded-lg transition-colors"
                >
                  <Book className="h-5 w-5" />
                  <span>{level} {language === 'mn' ? 'Дүрэм' : '文法'}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Сүүлийн хичээлүүд' : '最新の講座'}
            </h2>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-start space-x-4 p-4 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <BookOpen className="h-6 w-6 text-indigo-600 mt-1" />
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {language === 'mn' 
                        ? `N${i} түвшний дүрмийн тайлбар` 
                        : `N${i}文法の解説`}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {language === 'mn' ? '2 цагийн өмнө' : '2時間前'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Түргэн холбоос' : 'クイックリンク'}
            </h2>
            <div className="space-y-3">
              <QuickLink 
                icon={<GraduationCap className="h-5 w-5" />}
                title={language === 'mn' ? 'Дүрмийн тест' : '文法テスト'}
              />
              <QuickLink 
                icon={<Book className="h-5 w-5" />}
                title={language === 'mn' ? 'Өнөөдрийн дүрэм' : '今日の文法'}
              />
              <QuickLink 
                icon={<BookOpen className="h-5 w-5" />}
                title={language === 'mn' ? 'Жишээ өгүүлбэр' : '例文'}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const QuickLink: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <button className="w-full flex items-center space-x-3 px-4 py-3 text-gray-700 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
    {icon}
    <span>{title}</span>
  </button>
);

export default GrammarPage;