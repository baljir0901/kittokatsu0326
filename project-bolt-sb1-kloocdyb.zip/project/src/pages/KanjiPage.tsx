import React from 'react';
import { useStore } from '../store/useStore';
import { PenTool, BookOpen, GraduationCap } from 'lucide-react';

const KanjiPage: React.FC = () => {
  const { language } = useStore();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-4">
        {language === 'mn' ? 'Ханз' : '漢字'}
      </h1>
      <p className="text-gray-600 mb-8">
        {language === 'mn' 
          ? 'JLPT шалгалтын ханзны жагсаалт' 
          : 'JLPT試験の漢字リスト'}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {['N1', 'N2', 'N3', 'N4', 'N5'].map((level) => (
                <div key={level} className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{level}</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    {language === 'mn' ? 'Нийт ханз:' : '漢字総数:'} {level === 'N5' ? '100' : level === 'N4' ? '300' : level === 'N3' ? '650' : level === 'N2' ? '1000' : '2000'}
                  </p>
                  <button className="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors">
                    {language === 'mn' ? 'Үзэх' : '見る'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Өнөөдрийн ханз' : '今日の漢字'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { kanji: '愛', reading: 'あい', meaning: language === 'mn' ? 'Хайр' : '愛' },
                { kanji: '平', reading: 'へい', meaning: language === 'mn' ? 'Энх' : '平和' },
                { kanji: '和', reading: 'わ', meaning: language === 'mn' ? 'Эв' : '調和' },
                { kanji: '心', reading: 'こころ', meaning: language === 'mn' ? 'Сэтгэл' : '心' }
              ].map((item, i) => (
                <div key={i} className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-4xl font-bold text-gray-900 mb-2">{item.kanji}</div>
                  <div className="text-sm text-gray-600">{item.reading}</div>
                  <div className="text-sm text-gray-700 mt-1">{item.meaning}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Сургалтын хэрэгсэл' : '学習ツール'}
            </h2>
            <div className="space-y-4">
              <Tool 
                icon={<PenTool />}
                title={language === 'mn' ? 'Бичих дасгал' : '書き方練習'}
                description={language === 'mn' ? 'Ханз бичих дадал хэвших' : '漢字の書き方を練習する'}
              />
              <Tool 
                icon={<BookOpen />}
                title={language === 'mn' ? 'Унших дасгал' : '読み方練習'}
                description={language === 'mn' ? 'Ханз уншиж сурах' : '漢字の読み方を練習する'}
              />
              <Tool 
                icon={<GraduationCap />}
                title={language === 'mn' ? 'Түвшин шалгах' : 'レベルチェック'}
                description={language === 'mn' ? 'Өөрийн түвшинг мэдэх' : '自分のレベルを確認する'}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Tool: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
}> = ({ icon, title, description }) => (
  <div className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-indigo-50 transition-colors">
    <div className="text-indigo-600">{icon}</div>
    <div>
      <h3 className="font-medium text-gray-900">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  </div>
);

export default KanjiPage;