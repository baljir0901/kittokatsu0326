import React from 'react';
import { useStore } from '../store/useStore';
import { Volume2, PlayCircle, Headphones } from 'lucide-react';

const ListeningPage: React.FC = () => {
  const { language } = useStore();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-4">
        {language === 'mn' ? 'Сонсгол' : '聴解'}
      </h1>
      <p className="text-gray-600 mb-8">
        {language === 'mn' 
          ? 'JLPT шалгалтын сонсголын дасгалууд' 
          : 'JLPT試験の聴解問題'}
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Сүүлийн хичээлүүд' : '最新の講座'}
            </h2>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center space-x-4 p-4 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <PlayCircle className="h-8 w-8 text-indigo-600" />
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">
                      {language === 'mn' 
                        ? `N${i} Өдөр тутмын яриа` 
                        : `N${i} 日常会話`}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {language === 'mn' ? '15 минут' : '15分'}
                    </p>
                  </div>
                  <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                    {language === 'mn' ? 'Сонсох' : '聞く'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Түвшин сонгох' : 'レベルを選択'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {['N1', 'N2', 'N3', 'N4', 'N5'].map((level) => (
                <button
                  key={level}
                  className="flex items-center justify-center space-x-2 bg-gray-50 hover:bg-indigo-50 text-gray-700 hover:text-indigo-600 px-4 py-3 rounded-lg transition-colors"
                >
                  <Volume2 className="h-5 w-5" />
                  <span>{level} {language === 'mn' ? 'Сонсгол' : '聴解'}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Сонсголын төрөл' : '聴解の種類'}
            </h2>
            <div className="space-y-4">
              <ListeningType
                icon={<Headphones className="h-5 w-5" />}
                title={language === 'mn' ? 'Богино яриа' : '短い会話'}
                count="15"
              />
              <ListeningType
                icon={<Volume2 className="h-5 w-5" />}
                title={language === 'mn' ? 'Урт яриа' : '長い会話'}
                count="10"
              />
              <ListeningType
                icon={<PlayCircle className="h-5 w-5" />}
                title={language === 'mn' ? 'Мэдээ, зар' : 'ニュース・案内'}
                count="8"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const ListeningType: React.FC<{
  icon: React.ReactNode;
  title: string;
  count: string;
}> = ({ icon, title, count }) => {
  const { language } = useStore();
  
  return (
    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-indigo-50 transition-colors">
      <div className="flex items-center space-x-3">
        <div className="text-indigo-600">{icon}</div>
        <span className="font-medium text-gray-900">{title}</span>
      </div>
      <span className="text-sm text-gray-600">
        {count} {language === 'mn' ? 'дасгал' : '問題'}
      </span>
    </div>
  );
};

export default ListeningPage;