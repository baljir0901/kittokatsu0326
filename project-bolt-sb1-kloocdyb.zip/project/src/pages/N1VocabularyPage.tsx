import React, { useState, useRef, useEffect } from 'react';
import { Book, BookOpen, ChevronDown, ChevronRight, List, Volume2, Pause, Loader2 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { VocabularyItem } from '../types';
import { useVocabulary } from '../hooks/useVocabulary';

const N1VocabularyPage: React.FC = () => {
  const { language } = useStore();
  const { chapters, loading, error, getVocabularyForLesson } = useVocabulary();
  const [viewMode, setViewMode] = useState<'list' | 'card'>('card');
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<string | null>(null);
  const [expandedChapters, setExpandedChapters] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [vocabularyItems, setVocabularyItems] = useState<VocabularyItem[]>([]);
  const [loadingVocabulary, setLoadingVocabulary] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggleChapter = (chapterId: number) => {
    setExpandedChapters(prev =>
      prev.includes(chapterId)
        ? prev.filter(id => id !== chapterId)
        : [...prev, chapterId]
    );
  };

  const selectLesson = async (chapterId: number, lessonId: number) => {
    const chapterSimpleId = `CH${chapterId.toString().padStart(3, '0')}`;
    const lessonSimpleId = `L${chapterId.toString().padStart(3, '0')}-${lessonId.toString().padStart(3, '0')}`;

    setSelectedChapter(chapterSimpleId);
    setSelectedLesson(lessonSimpleId);

    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }

    setLoadingVocabulary(true);
    try {
      const items = await getVocabularyForLesson(chapterSimpleId, lessonSimpleId);
      setVocabularyItems(items);
    } catch (err) {
      console.error('Failed to load vocabulary items:', err);
      setVocabularyItems([]);
    } finally {
      setLoadingVocabulary(false);
    }
  };

  const toggleAudio = (audioUrl?: string) => {
    if (!audioUrl || !audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
  };

  const currentLesson = selectedChapter && selectedLesson
    ? chapters.find(c => `CH${c.id.toString().padStart(3, '0')}` === selectedChapter)
        ?.lessons.find(l => `L${l.chapter_id.toString().padStart(3, '0')}-${l.id.toString().padStart(3, '0')}` === selectedLesson)
    : null;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <p className="text-red-700">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <audio 
        ref={audioRef}
        src={currentLesson?.audio_url}
        onEnded={handleAudioEnded}
      />

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          {language === 'mn' ? 'N1 Үг, Хэллэг' : 'N1 語彙・表現'}
        </h1>
        <p className="text-gray-600">
          {language === 'mn' 
            ? 'JLPT N1 түвшний үг, хэллэгүүд. Жишээ өгүүлбэр, тайлбарын хамт.' 
            : 'JLPT N1レベルの語彙と表現。例文と説明付き。'}
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              {language === 'mn' ? 'Бүлгүүд' : 'チャプター'}
            </h2>
            <div className="space-y-2">
              {chapters.map(chapter => (
                <div key={chapter.id} className="space-y-1">
                  <button
                    onClick={() => toggleChapter(chapter.id)}
                    className="w-full flex items-center justify-between px-4 py-2 rounded-md hover:bg-gray-100 text-left"
                  >
                    <span className="text-gray-700">
                      {language === 'mn' ? chapter.title_mn : chapter.title_ja}
                    </span>
                    {expandedChapters.includes(chapter.id) ? (
                      <ChevronDown className="h-4 w-4 text-gray-500" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-gray-500" />
                    )}
                  </button>
                  {expandedChapters.includes(chapter.id) && (
                    <div className="ml-4 space-y-1">
                      {chapter.lessons.map(lesson => (
                        <button
                          key={lesson.id}
                          onClick={() => selectLesson(chapter.id, lesson.id)}
                          className={`w-full text-left px-4 py-2 rounded-md transition-colors ${
                            selectedChapter === `CH${chapter.id.toString().padStart(3, '0')}` &&
                            selectedLesson === `L${chapter.id.toString().padStart(3, '0')}-${lesson.id.toString().padStart(3, '0')}`
                              ? 'bg-indigo-100 text-indigo-700'
                              : 'hover:bg-gray-100 text-gray-600'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span>
                              {language === 'mn' ? lesson.title_mn : lesson.title_ja}
                              <span className="text-sm text-gray-500 ml-2">
                                ({lesson.word_count})
                              </span>
                            </span>
                            {lesson.audio_url && (
                              <Volume2 className="h-4 w-4 text-gray-400" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex-1">
          <div className="bg-white rounded-lg shadow-md">
            <div className="border-b border-gray-200 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <h3 className="text-lg font-semibold text-gray-900">
                    {selectedChapter && selectedLesson ? (
                      currentLesson?.title_ja
                    ) : (
                      language === 'mn' ? 'Бүх үгс' : '全ての単語'
                    )}
                  </h3>
                  {currentLesson?.audio_url && (
                    <button
                      onClick={() => toggleAudio(currentLesson.audio_url)}
                      className="p-2 rounded-full hover:bg-gray-100"
                    >
                      {isPlaying ? (
                        <Pause className="h-5 w-5 text-indigo-600" />
                      ) : (
                        <Volume2 className="h-5 w-5 text-indigo-600" />
                      )}
                    </button>
                  )}
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setViewMode('card')}
                    className={`p-2 rounded-md ${
                      viewMode === 'card'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'hover:bg-gray-100 text-gray-600'
                    }`}
                  >
                    <BookOpen className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded-md ${
                      viewMode === 'list'
                        ? 'bg-indigo-100 text-indigo-700'
                        : 'hover:bg-gray-100 text-gray-600'
                    }`}
                  >
                    <List className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4">
              {loadingVocabulary ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 text-indigo-600 animate-spin" />
                </div>
              ) : vocabularyItems.length > 0 ? (
                <div className={`grid gap-4 ${
                  viewMode === 'card' ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'
                }`}>
                  {vocabularyItems.map(item => (
                    viewMode === 'card' ? (
                      <VocabularyCard key={item.id} item={item} />
                    ) : (
                      <VocabularyListItem key={item.id} item={item} />
                    )
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  {language === 'mn' 
                    ? 'Сонгосон хэсэгт үг байхгүй байна.' 
                    : '選択された部分に単語がありません。'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const VocabularyCard: React.FC<{ item: VocabularyItem }> = ({ item }) => {
  const { language } = useStore();

  return (
    <div className="bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h4 className="text-xl font-bold text-gray-900">{item.kanji}</h4>
          <p className="text-sm text-gray-600">{item.hiragana}</p>
        </div>
        <Book className="h-5 w-5 text-indigo-600" />
      </div>
      <p className="text-gray-900 mb-4">
        {language === 'mn' ? item.meaning_mn : item.meaning_ja}
      </p>
      <div className="space-y-2">
        <p className="text-sm text-gray-800">{item.example_sentence}</p>
        <p className="text-sm text-gray-600">
          {language === 'mn' ? item.example_meaning_mn : item.example_meaning_ja}
        </p>
      </div>
    </div>
  );
};

const VocabularyListItem: React.FC<{ item: VocabularyItem }> = ({ item }) => {
  const { language } = useStore();

  return (
    <div className="border-b border-gray-200 py-4 hover:bg-gray-50 transition-colors">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-4">
            <div>
              <h4 className="text-lg font-semibold text-gray-900">{item.kanji}</h4>
              <p className="text-sm text-gray-600">{item.hiragana}</p>
            </div>
            <span className="text-gray-700">
              {language === 'mn' ? item.meaning_mn : item.meaning_ja}
            </span>
          </div>
        </div>
        <Book className="h-5 w-5 text-gray-400 hover:text-indigo-600 cursor-pointer" />
      </div>
    </div>
  );
};

export default N1VocabularyPage;