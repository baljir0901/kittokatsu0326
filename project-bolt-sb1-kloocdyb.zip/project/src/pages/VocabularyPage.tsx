import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Book, ChevronRight } from 'lucide-react';
import N1VocabularyPage from './N1VocabularyPage';
import type { JLPTLevel } from '../types';

const VocabularyPage: React.FC = () => {
  const { language } = useStore();
  const [selectedLevel, setSelectedLevel] = useState<JLPTLevel | null>(null);

  const levels: JLPTLevel[] = ['N1', 'N2', 'N3', 'N4', 'N5'];

  if (selectedLevel) {
    return <N1VocabularyPage />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-4">
        {language === 'mn' ? 'Япон хэлний үг' : '日本語の単語'}
      </h1>
      <p className="text-gray-600 mb-8">
        {language === 'mn' 
          ? 'JLPT түвшин бүрийн үг, хэллэг' 
          : 'JLPT各レベルの語彙・表現'}
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {levels.map((level) => (
          <button
            key={level}
            onClick={() => setSelectedLevel(level)}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all hover:scale-105"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Book className="h-6 w-6 text-indigo-600" />
                <h2 className="text-xl font-semibold text-gray-900">{level}</h2>
              </div>
              <ChevronRight className="h-5 w-5 text-gray-400" />
            </div>
            <div className="space-y-2">
              <p className="text-gray-700">
                {language === 'mn' 
                  ? 'Нийт үг:' 
                  : '単語数:'} {' '}
                {level === 'N5' ? '800' : 
                 level === 'N4' ? '1,500' : 
                 level === 'N3' ? '3,000' : 
                 level === 'N2' ? '6,000' : '10,000'}
              </p>
              <p className="text-sm text-gray-500">
                {language === 'mn'
                  ? 'Хичээл, жишээ өгүүлбэр, дасгал'
                  : '講座、例文、練習問題'}
              </p>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            {language === 'mn' ? 'Өнөөдрийн үгс' : '今日の単語'}
          </h2>
          <div className="space-y-4">
            {[
              { kanji: '理解', hiragana: 'りかい', meaning: language === 'mn' ? 'Ойлгох' : '理解する' },
              { kanji: '説明', hiragana: 'せつめい', meaning: language === 'mn' ? 'Тайлбарлах' : '説明する' },
              { kanji: '記憶', hiragana: 'きおく', meaning: language === 'mn' ? 'Санах ой' : '記憶する' }
            ].map((word, i) => (
              <div key={i} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div>
                  <p className="text-lg font-medium text-gray-900">{word.kanji}</p>
                  <p className="text-sm text-gray-500">{word.hiragana}</p>
                </div>
                <p className="text-gray-700">{word.meaning}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">
            {language === 'mn' ? 'Сүүлд үзсэн' : '最近見た単語'}
          </h2>
          <div className="space-y-4">
            {[
              { level: 'N3', count: '25' },
              { level: 'N2', count: '15' },
              { level: 'N1', count: '10' }
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <span className="text-indigo-600 font-medium">{item.level}</span>
                  <span className="text-gray-700">
                    {language === 'mn' ? 'Үзсэн үг' : '見た単語'}
                  </span>
                </div>
                <span className="text-gray-600">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VocabularyPage;