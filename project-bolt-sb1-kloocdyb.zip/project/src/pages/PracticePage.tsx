import React from 'react';
import { useStore } from '../store/useStore';

const PracticePage: React.FC = () => {
  const { language } = useStore();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-4">
        {language === 'mn' ? 'Дасгал ажил' : '練習問題'}
      </h1>
      <p className="text-gray-600 mb-8">
        {language === 'mn' 
          ? 'JLPT шалгалтын бэлтгэл дасгалууд' 
          : 'JLPT試験の練習問題'}
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {['N1', 'N2', 'N3', 'N4', 'N5'].map((level) => (
          <div key={level} className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">{level}</h2>
            <ul className="space-y-3">
              <li className="text-gray-600 hover:text-indigo-600 cursor-pointer">
                {language === 'mn' ? 'Өнөөдрийн дасгал' : '今日の練習'}
              </li>
              <li className="text-gray-600 hover:text-indigo-600 cursor-pointer">
                {language === 'mn' ? 'Сорил' : '小テスト'}
              </li>
              <li className="text-gray-600 hover:text-indigo-600 cursor-pointer">
                {language === 'mn' ? 'Өмнөх шалгалтууд' : '過去問'}
              </li>
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PracticePage;