import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Chapter, Lesson, VocabularyItem } from '../types';

export function useVocabulary() {
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        // Load chapters with their lessons
        const { data: chaptersData, error: chaptersError } = await supabase
          .from('chapters')
          .select(`
            *,
            lessons (*)
          `)
          .order('order_number');

        if (chaptersError) throw chaptersError;
        if (!chaptersData) throw new Error('No chapters data found');

        const formattedChapters: Chapter[] = chaptersData.map(chapter => ({
          id: chapter.order_number,
          simple_id: chapter.simple_id || `CH${chapter.order_number.toString().padStart(3, '0')}`,
          title_mn: chapter.title_mn,
          title_ja: chapter.title_ja,
          lessons: (chapter.lessons || []).map(lesson => ({
            id: lesson.order_number,
            simple_id: lesson.simple_id || `L${chapter.order_number.toString().padStart(3, '0')}-${lesson.order_number.toString().padStart(3, '0')}`,
            chapter_id: chapter.order_number,
            title_mn: lesson.title_mn,
            title_ja: lesson.title_ja,
            word_count: lesson.word_count || 0,
            audio_url: lesson.audio_url
          })).sort((a, b) => a.id - b.id)
        })).sort((a, b) => a.id - b.id);

        setChapters(formattedChapters);
      } catch (err) {
        console.error('Error loading chapters:', err);
        setError(err instanceof Error ? err.message : 'Failed to load vocabulary data');
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, []);

  async function getVocabularyForLesson(chapterId: string, lessonId: string): Promise<VocabularyItem[]> {
    try {
      // Get the vocabulary items directly using the simple IDs
      const { data, error } = await supabase
        .from('vocabulary_items_n1')
        .select('*')
        .eq('chapter_id', chapterId)
        .eq('lesson_id', lessonId)
        .order('order_number');

      if (error) throw error;
      if (!data) return [];

      return data.map(item => ({
        id: item.id,
        kanji: item.kanji || '',
        hiragana: item.hiragana || '',
        meaning_mn: item.translation || '',
        meaning_ja: item.translation || '',
        example_sentence: item.example_ja || '',
        example_meaning_mn: item.example_mn || '',
        example_meaning_ja: item.example_ja || '',
        chapter: chapterId,
        lesson: lessonId,
        jlpt_level: 'N1'
      }));
    } catch (err) {
      console.error('Error loading vocabulary:', err);
      throw new Error('Failed to load vocabulary items');
    }
  }

  return {
    chapters,
    loading,
    error,
    getVocabularyForLesson
  };
}