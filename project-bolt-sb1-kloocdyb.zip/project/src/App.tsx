import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import { useStore } from './store/useStore';
import { GraduationCap, BookOpen, MessageCircle, Users2, School } from 'lucide-react';
import VocabularyPage from './pages/VocabularyPage';
import PracticePage from './pages/PracticePage';
import GrammarPage from './pages/GrammarPage';
import KanjiPage from './pages/KanjiPage';
import ListeningPage from './pages/ListeningPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Header />
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/practice" element={<PracticePage />} />
            <Route path="/grammar" element={<GrammarPage />} />
            <Route path="/kanji" element={<KanjiPage />} />
            <Route path="/vocabulary" element={<VocabularyPage />} />
            <Route path="/listening" element={<ListeningPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

const Home: React.FC = () => {
  const { language } = useStore();

  return (
    <div className="space-y-8">
      <section className="bg-white p-8 rounded-lg shadow-md">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {language === 'mn' ? 'JLPT шалгалтын бэлтгэл' : 'JLPT 試験準備'}
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            {language === 'mn' 
              ? 'N1-N5 түвшний сорил, дасгал, хичээл материалууд' 
              : 'N1-N5レベルの問題集と学習教材'}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {['N1', 'N2', 'N3', 'N4', 'N5'].map((level) => (
              <button
                key={level}
                className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
              >
                {level}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <QuickStartCard
          icon={<GraduationCap className="h-8 w-8" />}
          title={language === 'mn' ? 'Түвшин тогтоох тест' : 'レベルチェック'}
          description={language === 'mn' 
            ? 'Өөрийн түвшинг тодорхойлох сорил өгөх' 
            : 'レベルチェックテストを受ける'}
        />
        <QuickStartCard
          icon={<BookOpen className="h-8 w-8" />}
          title={language === 'mn' ? 'Сүүлийн хичээлүүд' : '最新の講座'}
          description={language === 'mn' 
            ? 'Шинээр нэмэгдсэн хичээлүүд' 
            : '最近追加された講座'}
        />
        <QuickStartCard
          icon={<MessageCircle className="h-8 w-8" />}
          title={language === 'mn' ? 'Асуулт хариулт' : 'Q&A'}
          description={language === 'mn' 
            ? 'Багш, сурагчидтай харилцах' 
            : '先生と学生との交流'}
        />
      </div>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Users2 className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-xl font-semibold">
              {language === 'mn' ? 'Идэвхтэй форумууд' : 'アクティブな掲示板'}
            </h2>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="border-b pb-4 last:border-0 last:pb-0">
                <h3 className="font-medium text-gray-900">
                  {language === 'mn' 
                    ? `N${i} түвшний дүрмийн асуулт` 
                    : `N${i}文法についての質問`}
                </h3>
                <p className="text-sm text-gray-500">
                  {language === 'mn' ? '2 цагийн өмнө' : '2時間前'}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <School className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-xl font-semibold">
              {language === 'mn' ? 'Шинэ хичээлүүд' : '新しい講座'}
            </h2>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="border-b pb-4 last:border-0 last:pb-0">
                <h3 className="font-medium text-gray-900">
                  {language === 'mn' 
                    ? `N${i} Шинэ үгсийн хичээл` 
                    : `N${i}新しい単語の講座`}
                </h3>
                <p className="text-sm text-gray-500">
                  {language === 'mn' ? 'Өчигдөр нэмэгдсэн' : '昨日追加'}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const QuickStartCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
}> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center mb-4 text-indigo-600">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default App;