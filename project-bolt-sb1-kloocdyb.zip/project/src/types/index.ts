export type Language = 'mn' | 'ja';

export type JLPTLevel = 'N1' | 'N2' | 'N3' | 'N4' | 'N5';

export interface User {
  id: string;
  email: string;
  username: string;
  preferred_language: Language;
  current_level: JLPTLevel;
  study_streak: number;
  created_at: string;
}

export interface StudyProgress {
  user_id: string;
  level: JLPTLevel;
  category: string;
  score: number;
  completed_at: string;
}

export interface VocabularyItem {
  id: string;
  kanji: string;
  hiragana: string;
  meaning_mn: string;
  meaning_ja: string;
  example_sentence: string;
  example_meaning_mn: string;
  example_meaning_ja: string;
  chapter: string;
  lesson: string;
  jlpt_level: JLPTLevel;
}

export interface Chapter {
  id: number;
  simple_id: string;
  title_mn: string;
  title_ja: string;
  lessons: Lesson[];
}

export interface Lesson {
  id: number;
  simple_id: string;
  chapter_id: number;
  title_mn: string;
  title_ja: string;
  word_count: number;
  audio_url?: string;
}

export interface VocabularyN1Item {
  id: string;
  chapter_id: string;
  lesson_id: string;
  kanji: string;
  hiragana: string;
  translation: string;
  example_ja: string;
  example_mn: string;
  order_number: number;
  created_at?: string;
  updated_at?: string;
}