import { create } from 'zustand';
import { Language, User } from '../types';

interface Store {
  language: Language;
  setLanguage: (lang: Language) => void;
  user: User | null;
  setUser: (user: User | null) => void;
}

export const useStore = create<Store>((set) => ({
  language: 'mn',
  setLanguage: (lang) => set({ language: lang }),
  user: null,
  setUser: (user) => set({ user }),
}));