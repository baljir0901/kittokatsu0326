import React from 'react';
import { useStore } from '../store/useStore';
import { Languages, User, Search, Bell } from 'lucide-react';
import { Link } from 'react-router-dom';

const Header: React.FC = () => {
  const { language, setLanguage, user } = useStore();

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Languages className="h-8 w-8 text-indigo-600" />
            <span className="text-xl font-bold text-gray-900">
              {language === 'mn' ? 'JLPT Монгол' : 'JLPT モンゴル'}
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <NavLink to="/practice" text={language === 'mn' ? 'Дасгал' : '練習'} />
            <NavLink to="/grammar" text={language === 'mn' ? 'Дүрэм' : '文法'} />
            <NavLink to="/kanji" text={language === 'mn' ? 'Ханз' : '漢字'} />
            <NavLink to="/vocabulary" text={language === 'mn' ? 'Үг' : '単語'} />
            <NavLink to="/listening" text={language === 'mn' ? 'Сонсгол' : '聴解'} />
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Search className="h-5 w-5 text-gray-600" />
            </button>
            
            <button
              onClick={() => setLanguage(language === 'mn' ? 'ja' : 'mn')}
              className="hidden md:block px-3 py-1 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              {language === 'mn' ? '日本語' : 'Монгол'}
            </button>

            {user ? (
              <div className="flex items-center space-x-4">
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <Bell className="h-5 w-5 text-gray-600" />
                </button>
                <Link 
                  to="/profile" 
                  className="flex items-center space-x-2 px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  <User className="h-5 w-5" />
                  <span>{user.username}</span>
                </Link>
              </div>
            ) : (
              <Link
                to="/login"
                className="px-4 py-2 bg-indigo-600 text-white rounded-md font-medium hover:bg-indigo-700"
              >
                {language === 'mn' ? 'Нэвтрэх' : 'ログイン'}
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

const NavLink: React.FC<{ to: string; text: string }> = ({ to, text }) => (
  <Link 
    to={to} 
    className="text-gray-700 hover:text-indigo-600 font-medium transition-colors"
  >
    {text}
  </Link>
);

export default Header;