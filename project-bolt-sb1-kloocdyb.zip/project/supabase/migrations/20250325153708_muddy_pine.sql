/*
  # Fix vocabulary schema and data structure

  1. Changes
    - Drop and recreate vocabulary_items_N1 table with correct structure
    - Add proper constraints and indexes
    - Add sample data
    
  2. Security
    - Enable RLS
    - Add policies for public read access
    - Add policies for admin write access
*/

-- Drop existing table
DROP TABLE IF EXISTS vocabulary_items_N1;

-- Create new table with correct structure
CREATE TABLE vocabulary_items_N1 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id uuid REFERENCES chapters(id) ON DELETE CASCADE,
  lesson_id uuid REFERENCES lessons(id) ON DELETE CASCADE,
  kanji text,
  hiragana text,
  translation text,
  example_ja text,
  example_mn text,
  order_number integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for better performance
CREATE INDEX vocabulary_items_n1_chapter_id_idx ON vocabulary_items_N1(chapter_id);
CREATE INDEX vocabulary_items_n1_lesson_id_idx ON vocabulary_items_N1(lesson_id);
CREATE INDEX vocabulary_items_n1_order_number_idx ON vocabulary_items_N1(order_number);

-- Enable Row Level Security
ALTER TABLE vocabulary_items_N1 ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read vocabulary items"
  ON vocabulary_items_N1
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admins can modify vocabulary items"
  ON vocabulary_items_N1
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Insert sample data
WITH first_chapter AS (
  SELECT id FROM chapters WHERE order_number = 1 LIMIT 1
),
first_lesson AS (
  SELECT id FROM lessons WHERE order_number = 1 AND chapter_id = (SELECT id FROM first_chapter) LIMIT 1
)
INSERT INTO vocabulary_items_N1 (chapter_id, lesson_id, kanji, hiragana, translation, example_ja, example_mn, order_number)
SELECT 
  (SELECT id FROM first_chapter),
  (SELECT id FROM first_lesson),
  kanji,
  hiragana,
  translation,
  example_ja,
  example_mn,
  order_number
FROM (
  VALUES 
    ('概して', 'がいして', 'Ерөнхийдөө, голдуу', '日本人は概して勤勉だ。', 'Япончууд ерөнхийдөө хичээнгүй.', 1),
    ('該当', 'がいとう', 'Хамаарах, холбогдох', 'この規則は外国人にも該当する。', 'Энэ дүрэм гадаадын иргэдэд ч мөн хамаарна.', 2)
) AS t(kanji, hiragana, translation, example_ja, example_mn, order_number)
ON CONFLICT (id) DO NOTHING;