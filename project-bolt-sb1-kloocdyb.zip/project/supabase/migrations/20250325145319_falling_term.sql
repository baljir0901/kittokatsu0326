/*
  # Create vocabulary and audio tables

  1. New Tables (if not exist)
    - `chapters`
      - `id` (uuid, primary key)
      - `title_mn` (text)
      - `title_ja` (text)
      - `order_number` (integer)
      - `created_at` (timestamp)

    - `lessons`
      - `id` (uuid, primary key)
      - `chapter_id` (uuid, foreign key)
      - `title_mn` (text)
      - `title_ja` (text)
      - `order_number` (integer)
      - `word_count` (integer)
      - `audio_url` (text)
      - `created_at` (timestamp)

    - `vocabulary`
      - `id` (uuid, primary key)
      - `lesson_id` (uuid, foreign key)
      - `kanji` (text)
      - `hiragana` (text)
      - `meaning_mn` (text)
      - `meaning_ja` (text)
      - `example_sentence` (text)
      - `example_meaning_mn` (text)
      - `example_meaning_ja` (text)
      - `audio_url` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read data
    - Add policies for admin users to manage data
*/

DO $$ 
BEGIN

  -- Create chapters table if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'chapters') THEN
    CREATE TABLE chapters (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      title_mn text NOT NULL,
      title_ja text NOT NULL,
      order_number integer NOT NULL,
      created_at timestamptz DEFAULT now()
    );

    ALTER TABLE chapters ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read chapters"
      ON chapters
      FOR SELECT
      TO public
      USING (true);

    CREATE POLICY "Only admins can modify chapters"
      ON chapters
      FOR ALL
      TO authenticated
      USING (auth.jwt() ->> 'role' = 'admin')
      WITH CHECK (auth.jwt() ->> 'role' = 'admin');
  END IF;

  -- Create lessons table if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'lessons') THEN
    CREATE TABLE lessons (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      chapter_id uuid REFERENCES chapters(id) ON DELETE CASCADE,
      title_mn text NOT NULL,
      title_ja text NOT NULL,
      order_number integer NOT NULL,
      word_count integer DEFAULT 0,
      audio_url text,
      created_at timestamptz DEFAULT now()
    );

    ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read lessons"
      ON lessons
      FOR SELECT
      TO public
      USING (true);

    CREATE POLICY "Only admins can modify lessons"
      ON lessons
      FOR ALL
      TO authenticated
      USING (auth.jwt() ->> 'role' = 'admin')
      WITH CHECK (auth.jwt() ->> 'role' = 'admin');
  END IF;

  -- Create vocabulary table if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'vocabulary') THEN
    CREATE TABLE vocabulary (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      lesson_id uuid REFERENCES lessons(id) ON DELETE CASCADE,
      kanji text NOT NULL,
      hiragana text NOT NULL,
      meaning_mn text NOT NULL,
      meaning_ja text NOT NULL,
      example_sentence text,
      example_meaning_mn text,
      example_meaning_ja text,
      audio_url text,
      created_at timestamptz DEFAULT now()
    );

    ALTER TABLE vocabulary ENABLE ROW LEVEL SECURITY;

    CREATE POLICY "Anyone can read vocabulary"
      ON vocabulary
      FOR SELECT
      TO public
      USING (true);

    CREATE POLICY "Only admins can modify vocabulary"
      ON vocabulary
      FOR ALL
      TO authenticated
      USING (auth.jwt() ->> 'role' = 'admin')
      WITH CHECK (auth.jwt() ->> 'role' = 'admin');
  END IF;

  -- Create indexes if they don't exist
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'lessons_chapter_id_idx') THEN
    CREATE INDEX lessons_chapter_id_idx ON lessons(chapter_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'vocabulary_lesson_id_idx') THEN
    CREATE INDEX vocabulary_lesson_id_idx ON vocabulary(lesson_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'chapters_order_number_idx') THEN
    CREATE INDEX chapters_order_number_idx ON chapters(order_number);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'lessons_order_number_idx') THEN
    CREATE INDEX lessons_order_number_idx ON lessons(order_number);
  END IF;

END $$;