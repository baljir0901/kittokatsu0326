/*
  # Add simple_id generation and initial data
  
  1. Changes
    - Add triggers for simple_id generation with proper error handling
    - Add initial chapter and lesson data
    - Add sample vocabulary items
  
  2. Security
    - Maintains existing RLS policies
*/

-- Add triggers for simple_id generation
CREATE OR REPLACE FUNCTION generate_simple_id() RETURNS trigger AS $$
BEGIN
  IF TG_TABLE_NAME = 'chapters' THEN
    NEW.simple_id := 'CH' || LPAD(NEW.order_number::text, 3, '0');
  ELSIF TG_TABLE_NAME = 'lessons' THEN
    -- Get the chapter's order number safely
    NEW.simple_id := (
      WITH chapter_data AS (
        SELECT order_number 
        FROM chapters 
        WHERE id = NEW.chapter_id 
        LIMIT 1
      )
      SELECT 'L' || 
             LPAD(COALESCE((SELECT order_number FROM chapter_data), 0)::text, 3, '0') || 
             '-' || 
             LPAD(NEW.order_number::text, 3, '0')
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS chapters_simple_id_trigger ON chapters;
DROP TRIGGER IF EXISTS lessons_simple_id_trigger ON lessons;

-- Create new triggers
CREATE TRIGGER chapters_simple_id_trigger
  BEFORE INSERT ON chapters
  FOR EACH ROW
  EXECUTE FUNCTION generate_simple_id();

CREATE TRIGGER lessons_simple_id_trigger
  BEFORE INSERT ON lessons
  FOR EACH ROW
  EXECUTE FUNCTION generate_simple_id();

-- Insert initial chapter data
INSERT INTO chapters (title_mn, title_ja, title_en, order_number)
VALUES 
  ('Хүн хоорондын харилцаа', '人と人との関係', 'Human Relationships', 1),
  ('Амьдрал', '暮らし', 'Daily Life', 2)
ON CONFLICT (id) DO NOTHING;

-- Insert initial lesson data
WITH first_chapter AS (
  SELECT id FROM chapters WHERE order_number = 1 LIMIT 1
)
INSERT INTO lessons (chapter_id, title_mn, title_ja, title_en, order_number, audio_url)
SELECT 
  (SELECT id FROM first_chapter),
  title_mn,
  title_ja,
  title_en,
  order_number,
  audio_url
FROM (
  VALUES 
    ('Гэр бүл', '家族', 'Family', 1, 'https://example.com/audio/1-1.mp3'),
    ('Найз нөхөд', '友人', 'Friends', 2, 'https://example.com/audio/1-2.mp3')
) AS t(title_mn, title_ja, title_en, order_number, audio_url)
ON CONFLICT (id) DO NOTHING;

-- Insert sample vocabulary
INSERT INTO vocabulary (lesson_id, kanji, hiragana, meaning_mn, meaning_ja, example_sentence, example_meaning_mn, example_meaning_ja)
VALUES 
  ('L001-001', '概して', 'がいして', 'Ерөнхийдөө, голдуу', '一般的に、だいたい', '日本人は概して勤勉だ。', 'Япончууд ерөнхийдөө хичээнгүй.', '日本人は一般的に努力家である。'),
  ('L001-001', '該当', 'がいとう', 'Хамаарах, холбогдох', 'あてはまること', 'この規則は外国人にも該当する。', 'Энэ дүрэм гадаадын иргэдэд ч мөн хамаарна.', 'この規則は外国人にも適用される。')
ON CONFLICT (id) DO NOTHING;