/*
  # Create and configure vocabulary_items_N1 table
  
  1. New Tables
    - `vocabulary_items_N1`
      - `id` (uuid, primary key)
      - `chapter_id` (text)
      - `lesson_id` (text)
      - `kanji` (text)
      - `hiragana` (text)
      - `translation` (text)
      - `example_ja` (text)
      - `example_mn` (text)
      - `order_number` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  
  2. Constraints
    - Check constraints for chapter_id and lesson_id format
    - Indexes for better query performance
  
  3. Security
    - Enable RLS
    - Add policies for public read access
*/

-- Create the vocabulary_items_N1 table
CREATE TABLE IF NOT EXISTS vocabulary_items_N1 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chapter_id text NOT NULL,
  lesson_id text NOT NULL,
  kanji text,
  hiragana text,
  translation text,
  example_ja text,
  example_mn text,
  order_number integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT chapter_id_format CHECK (chapter_id ~ '^CH[0-9]{3}$'),
  CONSTRAINT lesson_id_format CHECK (lesson_id ~ '^L[0-9]{3}-[0-9]{3}$')
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS vocabulary_items_n1_chapter_id_idx ON vocabulary_items_N1(chapter_id);
CREATE INDEX IF NOT EXISTS vocabulary_items_n1_lesson_id_idx ON vocabulary_items_N1(lesson_id);
CREATE INDEX IF NOT EXISTS vocabulary_items_n1_order_number_idx ON vocabulary_items_N1(order_number);

-- Enable Row Level Security
ALTER TABLE vocabulary_items_N1 ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read vocabulary items"
  ON vocabulary_items_N1
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Only admins can modify vocabulary items"
  ON vocabulary_items_N1
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Insert some sample data
INSERT INTO vocabulary_items_N1 (chapter_id, lesson_id, kanji, hiragana, translation, example_ja, example_mn, order_number)
VALUES 
  ('CH001', 'L001-001', '概して', 'がいして', 'Ерөнхийдөө, голдуу', '日本人は概して勤勉だ。', 'Япончууд ерөнхийдөө хичээнгүй.', 1),
  ('CH001', 'L001-001', '該当', 'がいとう', 'Хамаарах, холбогдох', 'この規則は外国人にも該当する。', 'Энэ дүрэм гадаадын иргэдэд ч мөн хамаарна.', 2)
ON CONFLICT (id) DO NOTHING;