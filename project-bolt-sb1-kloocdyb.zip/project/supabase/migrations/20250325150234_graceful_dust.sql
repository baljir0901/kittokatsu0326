/*
  # Add simple IDs for frontend compatibility

  1. Changes
    - Add simple_id columns to chapters and lessons tables
    - Update vocabulary table to use composite lesson reference
*/

DO $$ 
BEGIN

  -- Add simple_id to chapters if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'chapters' AND column_name = 'simple_id'
  ) THEN
    ALTER TABLE chapters ADD COLUMN simple_id text;
  END IF;

  -- Add simple_id to lessons if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'lessons' AND column_name = 'simple_id'
  ) THEN
    ALTER TABLE lessons ADD COLUMN simple_id text;
  END IF;

  -- Update vocabulary lesson_id to use text if it doesn't exist
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'vocabulary' AND column_name = 'lesson_id' AND data_type = 'uuid'
  ) THEN
    -- Create temporary column
    ALTER TABLE vocabulary ADD COLUMN temp_lesson_id text;
    
    -- Drop the foreign key constraint
    ALTER TABLE vocabulary DROP CONSTRAINT vocabulary_lesson_id_fkey;
    
    -- Rename the old column
    ALTER TABLE vocabulary RENAME COLUMN lesson_id TO old_lesson_id;
    
    -- Rename the new column
    ALTER TABLE vocabulary RENAME COLUMN temp_lesson_id TO lesson_id;
    
    -- Drop the old column
    ALTER TABLE vocabulary DROP COLUMN old_lesson_id;
  END IF;

END $$;